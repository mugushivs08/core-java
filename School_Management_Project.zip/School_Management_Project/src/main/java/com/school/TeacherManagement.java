package com.school;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class TeacherManagement {
	
	private static Connection conn;
	private static PreparedStatement pst;
	private static ResultSet rs;
	
	public static void DisplayTeacher() throws SQLException {
		conn=SchoolConnection.getConnection();
		String t="select * from teacher";
		pst=conn.prepareStatement(t);
		rs=pst.executeQuery();
		
		System.out.println("tid\ttsalary\t\ttsalarypaid\t\ttname\t\ttsubject");
		while(rs.next()) {
			int id=rs.getInt("tid");
			String tn=rs.getString("tname");
			String ts=rs.getString("tsubject");
			float tsal=rs.getFloat("tsalary");
			float tsalpaid=rs.getFloat("tsalarypaid");
			
			System.out.println(id+"\t"+tsal+"\t\t"+tsalpaid+"\t\t\t"+tn+"\t\t"+ts);
		}
	}
	
	public static void AddTeacher() throws SQLException {
		conn=SchoolConnection.getConnection();
		int id;
		String tn;
		String tsub;
		float tsal;
		float tsalpaid;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter teacher id");
		id=sc.nextInt();
		String s="Select * from teacher where tid=?";
		 pst=conn.prepareStatement(s);
		 pst.setInt(1, id);
		 rs=pst.executeQuery();
		 if(!rs.next()) {
		System.out.println("Enter teacher name");
		tn=sc.next();
		System.out.println("Enter teacher special subject ");
		tsub=sc.next();
		System.out.println("Enter teacher salary");
		tsal=sc.nextFloat();
		System.out.println("Enter salary paid to teacher");
		tsalpaid=sc.nextFloat();
		
		
		
		String t="insert into teacher values(?,?,?,?,?)";
		pst=conn.prepareStatement(t);
		
		pst.setInt(1, id);
		pst.setString(2, tn);
		pst.setString(3, tsub);
		pst.setFloat(4, tsal);
		pst.setFloat(5, tsalpaid);
		
		int rv1=pst.executeUpdate();
		
		if(rv1>0) {
			System.out.println("Record is inserted");
		}else {
			System.out.println("Not inserted");
		}
		}else {
			System.out.println("Teacher tid "+id+" already exists");
			System.out.println("Enter some other tid to insert record");
		}
		
	}
	
	public static void DeleteTeacher() throws SQLException {
		conn=SchoolConnection.getConnection();
		int id;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter teachers id you want to delete");
		id=sc.nextInt();
		
		String s = "select * from teacher where tid=?";
		pst=conn.prepareStatement(s);
		pst.setInt(1, id);
		rs=pst.executeQuery();
		
		if(rs.next()) {
			String del="delete from teacher where tid=?";
			pst=conn.prepareStatement(del);
			pst.setInt(1, id);
			
			int rv=pst.executeUpdate();
			
			if(rv>0) {
				System.out.println("Record has been deleted");
			}else {
				System.out.println("Error while deleting record");
			}
		}else {
			System.out.println("Teacher tid"+id+"does not exists");
		}
		
	}
	public static void UpdateTeacher() throws SQLException {
		conn=SchoolConnection.getConnection();
		int id;
		float tspaid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter teacher id u want update");
		id=sc.nextInt();
		String s="select tsalary,tsalarypaid from teacher where tid=?";
		 pst=conn.prepareStatement(s);
		 pst.setInt(1, id);
		 rs=pst.executeQuery();
		 float salarypending;
		 float totalsalary=0;
		 float salarypaid=0;
		 if(rs.next()) {
			  totalsalary=rs.getFloat("tsalary");
			  salarypaid=rs.getFloat("tsalarypaid");
			  
		 
			  salarypending=totalsalary-salarypaid;
		     System.out.println("Pending salary is = "+salarypending);
		     if(salarypending !=0) {
		      System.out.println("Enter salary paid to teacher ");
		      tspaid=sc.nextFloat();
			 String upd="update teacher set tsalarypaid=? where tid=?";
			 pst=conn.prepareStatement(upd);
			 pst.setFloat(1, (tspaid+salarypaid));
			 pst.setInt(2, id);
			 
			 int rv=pst.executeUpdate();
			 
			 if(rv>0) {
				 System.out.println("Record has been updated");
			 }else {
				 System.out.println("Error!!!");
			 }
		 }
		 }else {
			 System.out.println(id+" tid does not exists");
		 }
		 
	}
	public static double TotalSalaryPaid() throws SQLException {
		 conn=SchoolConnection.getConnection();
		  double value=0.0;
		     pst=conn.prepareStatement("select sum(tsalarypaid) from teacher ");
		     rs = pst.executeQuery();
		     rs.next();
		     String sum = rs.getString(1);
		     System.out.println("Salarypaid to teachers = "+sum+" Rs");
		     value = Double.parseDouble(sum);
		     return value;
		 }
}
