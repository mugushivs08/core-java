package com.school;

import java.sql.SQLException;
import java.util.Scanner;

public class MainSchoolHandler {

	public static void main(String[] args) throws SQLException {
		System.out.println("----Login in---");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter username");
		String uname=sc.next();
		System.out.println("Enter password");
		String upass=sc.next();
		if(uname.equals("gopal") && upass.equals("gopal@123")) {
		int whichdata;
		 int choice;
		 char ch;
		
		
		System.out.println("Select any");
		System.out.println("11. Student Data");
		System.out.println("12. Teacher Data");
		System.out.println("13. Calculate profit and loss of school");
		 whichdata=sc.nextInt();
		 switch(whichdata) {
		 case 11: 
			 
			
		
		    while(true) {
			System.out.println("***********Student Details*************");
			System.out.println("Choose a action u want to perform");
			System.out.println("1. Display student details");
			System.out.println("2. Add new Student details");
			System.out.println("3. Delete student details");
			System.out.println("4. update student details");
			System.out.println("5. Total fees paid by student");
			
			choice=sc.nextInt();
			switch(choice) {
			
			case 1: // Display
				    System.out.println("Display all student details");
				    StudentManagement.DisplayStudent();
				    break;
			case 2: //Insert
				    System.out.println("Add new student");
				    StudentManagement.AddStudent();
				    break;
			case 3: //Delete
				    System.out.println("Delete student details");
				    StudentManagement.DeleteStudent();
				    break;
			case 4://Update
				    System.out.println("Update student details");
				    StudentManagement.UpdateStudent();
				    break;
			case 5://totalfees
				    System.out.println("Totalfeespaid by the students ");
				    StudentManagement.TotalFeesPaid();
				    break;
	        default: System.out.println("Invalid input");
			}
			System.out.println("Do u want to continue y/n");
			ch=sc.next().charAt(0);
			if(ch=='n' || ch=='N')
				break;
		}
		System.out.println("Logout student successfully");
		
		 case 12:
			 System.out.println("Do u want to enter teachers details y/n");
				ch=sc.next().charAt(0);
				if(ch=='n' || ch=='N') {
				System.out.println("Logout successfully");
				break;
				
				}
		    while(true) {
			System.out.println("***********Teacher Details*************");
			System.out.println("Choose a action u want to perform");
			System.out.println("1. Display teacher details");
			System.out.println("2. Add new teacher details");
			System.out.println("3. Delete teacher details");
			System.out.println("4. Update teacher details");
			System.out.println("5. Total salary paid to teachers");
			
			choice=sc.nextInt();
			switch(choice) {
			
			case 1: // Display
				    System.out.println("Display all teacher details");
				    TeacherManagement.DisplayTeacher();
				    break;
			case 2://Add
				    System.out.println("Add new teacher details");
				    TeacherManagement.AddTeacher();
				    break;
			case 3://Delete
				    System.out.println("Delete teacher record");
				    TeacherManagement.DeleteTeacher();
				    break;
			case 4://update
				    System.out.println("Update teacher record");
				    TeacherManagement.UpdateTeacher();
				    break;
			case 5://totalfeespaid
				     System.out.println("Totalsalarypaid to teacher is ");
				     TeacherManagement.TotalSalaryPaid();
				     break;
	        default: System.out.println("Invalid input");
			}
			System.out.println("Do u want to continue y/n");
			ch=sc.next().charAt(0);
			if(ch=='n' || ch=='N')
				break;
		}
		 System.out.println("Logout teacher successfully");
		 case 13:// Profit loss calculation
			     System.out.println("Calculate profit loss of school");
			     double sf=StudentManagement.TotalFeesPaid();
			     double ts=TeacherManagement.TotalSalaryPaid();
			     double Totalmoney=sf-ts;
			     System.out.println("Total amount = "+Totalmoney+" Rs");
			     if(Totalmoney<0) {
			    	 System.out.println("School is running in loss");
			     }else if(Totalmoney>0)  {
			    	 System.out.println("School is running in profit");
			     }else if(Totalmoney==0) {
			    	 System.out.println("School is neither in loss nor in profit");
			     }else {
			    	 System.out.println("Something went wrong");
			     
			     break;
		}
	}
	}else {
		System.out.println("Incorrect password");
		
	}
	}
}
