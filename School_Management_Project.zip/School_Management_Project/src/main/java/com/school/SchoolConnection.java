package com.school;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class SchoolConnection {
		
	private static String driver="com.mysql.cj.jdbc.Driver";
	private static String url="jdbc:mysql://localhost:3306/school_management_system";

	private static String un="root";
	private static String up="root";
	
	private static Connection conn=null;
	private static PreparedStatement pst;
	private static ResultSet rs=null;
	
	public static Connection getConnection() {
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			if(conn==null) {
				System.out.println("Connection error!!!");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
}
