package com.school;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class StudentManagement {
	
	private static Connection conn;
	private static PreparedStatement pst;
	private static ResultSet rs;
	
	public static void DisplayStudent() throws SQLException {
		conn=SchoolConnection.getConnection();
		String s="Select * from student ";
		pst=conn.prepareStatement(s);
		rs=pst.executeQuery();
	
		
		System.out.println("sid\tsname\tsphone\t\tsaddress\tfees\t\tfeespaid");
		while(rs.next()) {
			int id=rs.getInt("sid");
			String sn=rs.getString("sname");
			int sph=rs.getInt("sphone");
			String sadd=rs.getString("saddress");
			float sfees=rs.getFloat("fees");
			float sfpaid=rs.getFloat("feespaid");
			
			System.out.println(id+"\t"+sn+"\t"+sph+"\t"+sadd+"\t\t"+sfees+"\t\t"+sfpaid);
			}
	}
	
	public static void AddStudent() throws SQLException {
		conn=SchoolConnection.getConnection();
		int id;
		String sn;
		int sph;
		String sadd;
		float sfees;
		float feespaid;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student id");
		id=sc.nextInt();
		String s="Select * from student where sid=?";
		 pst=conn.prepareStatement(s);
		 pst.setInt(1, id);
		 
		 rs=pst.executeQuery();
		 if(!rs.next()) {
		System.out.println("Enter student name");
		sn=sc.next();
		System.out.println("Enter students phone number");
		sph=sc.nextInt();
		System.out.println("Enter student address");
		sadd=sc.next();
		System.out.println("Enter student fees");
		sfees=sc.nextFloat();
		System.out.println("Enter student paid fees");
		feespaid=sc.nextFloat();
		
		
		 
		String sel="insert into student values(?,?,?,?,?,?)";
		pst=conn.prepareStatement(sel);
		
		pst.setInt(1, id);
		pst.setString(2, sn);
		pst.setInt(3, sph);
		pst.setString(4, sadd);
		pst.setFloat(5, sfees);
		pst.setFloat(6, feespaid);
		
		int rv=pst.executeUpdate();
		
		if(rv>0) {
			System.out.println("Record is inserted");
		}else {
			System.out.println("Not inserted");
		}
		 }else {
			 System.out.println("Student sid "+id+" already exists");
			 System.out.println("Enter other sid if u want to insert");
		 }
	}
	
	 public static void DeleteStudent() throws SQLException {
		 conn=SchoolConnection.getConnection();
		 int id;
		 Scanner sc =new Scanner(System.in);
		 System.out.println("Enter student id u want to delete");
		 id=sc.nextInt();
		 String s="Select * from student where sid=?";
		 pst=conn.prepareStatement(s);
		 pst.setInt(1, id);
		 rs=pst.executeQuery();
		 
		 if(rs.next()) {
			 String del="delete from student where sid=?";
			 pst=conn.prepareStatement(del);
			 pst.setInt(1, id);
			 
			 int rv=pst.executeUpdate();
			 if(rv>0) {
				 System.out.println("Record has been deleted");
			 }else {
				 System.out.println("Error while deleting record");
			 }
		 }else {
			 System.out.println("Student sid "+id+" does not exists");
		 }
	 }
	 public static void UpdateStudent() throws SQLException {
		 conn=SchoolConnection.getConnection();
		 int id;
		 float sfpaid;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter student id you want to update");
		 id=sc.nextInt();
		 String s="select fees,feespaid from student where sid=?";
		 pst=conn.prepareStatement(s);
		 pst.setInt(1, id);
		 rs=pst.executeQuery();
		 float feespending;
		 float totalfees=0;
		 float feespaid=0;
		 if(rs.next()) {
			  totalfees=rs.getFloat("fees");
			  feespaid=rs.getFloat("feespaid");
			  
		 
		     feespending=totalfees-feespaid;
		     System.out.println("Pending fees is = "+feespending);
		     if(feespending !=0) {
		      System.out.println("Enter feespaid by student ");
		      sfpaid=sc.nextFloat();
			 String upd="update student set feespaid=? where sid=?";
			 pst=conn.prepareStatement(upd);
			 pst.setFloat(1, (sfpaid+feespaid));
			 pst.setInt(2, id);
			 
			 int rv=pst.executeUpdate();
			 
			 if(rv>0) {
				 System.out.println("Record has been updated");
			 }else {
				 System.out.println("Error!!!");
			 }
		 }
		 }else {
			 System.out.println(id+" sid does not exists");
		 }
		 
	 }
	 
	 public static double TotalFeesPaid() throws SQLException {
		 conn=SchoolConnection.getConnection();
		  double value=0.0;
		     pst=conn.prepareStatement("select sum(feespaid) from student ");
		     rs = pst.executeQuery();
		     rs.next();
		     String sum = rs.getString(1);
		     System.out.println("feespaid by students = "+sum+" Rs");
		     value = Double.parseDouble(sum);
		     return value;
		 }
	 }
	

